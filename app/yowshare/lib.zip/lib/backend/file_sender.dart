import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';

class FileSender {
  static bool _stopFlag = false;

  static void stopAll() {
    _stopFlag = true;
  }

  static Future<void> sendFiles({
    required List<PlatformFile> files,
    required String ip,
    required int port,
    required Function(double) onProgress,
    required Function(String) onSpeed,
    required Function(String) onETA,
    required Function() onComplete,
  }) async {
    _stopFlag = false;

    // 1. Handshake
    final accepted = await _handshake(ip, port, files.length);
    if (!accepted) return;

    // 2. Start Sending Files
    int totalBytes = files.fold(0, (sum, f) => sum + f.size);
    int sentBytesTotal = 0;

    for (final file in files) {
      if (_stopFlag) return;

      final filePath = file.path!;
      final fileBytes = File(filePath).openRead();

      final url = Uri.parse("http://$ip:$port/upload");

      final req = await HttpClient().postUrl(url);

      req.headers.set("x-file-name", file.name);
      int fileBytesSent = 0;

      final stopwatch = Stopwatch()..start();

      await for (var chunk in fileBytes) {
        if (_stopFlag) return;

        req.add(chunk);
        fileBytesSent += chunk.length;
        sentBytesTotal += chunk.length;

        // % for this device
        double percent = (sentBytesTotal / totalBytes) * 100;
        onProgress(percent);

        // Speed
        double seconds = stopwatch.elapsedMilliseconds / 1000;
        double speedMB = (fileBytesSent / (1024 * 1024)) / seconds;
        onSpeed("${speedMB.toStringAsFixed(2)} MB/s");

        // ETA
        double remainingBytes = (totalBytes - sentBytesTotal) as double;
        double etaSeconds = (remainingBytes / (1024 * 1024)) / speedMB;
        onETA("${etaSeconds.toStringAsFixed(0)}s remaining");
      }

      final response = await req.close();
      final respBody = await response.transform(utf8.decoder).join();
      print("UPLOAD RESPONSE: $respBody");
    }

    onProgress(100);
    onSpeed("0 MB/s");
    onETA("Completed");

    onComplete();
  }

  // -----------------------------
  // Handshake with receiver
  // -----------------------------
  static Future<bool> _handshake(String ip, int port, int fileCount) async {
    try {
      final url = Uri.parse("http://$ip:$port/handshake");
      final req = await HttpClient().postUrl(url);

      req.write(jsonEncode({
        "deviceName": Platform.localHostname,
        "fileCount": fileCount,
      }));

      final resp = await req.close();
      final data = await resp.transform(utf8.decoder).join();
      final json = jsonDecode(data);

      return json["accepted"] == true;
    } catch (e) {
      print("HANDSHAKE ERROR: $e");
      return false;
    }
  }
}
