import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'dart:io';

class Notify {
  static final _notifications = FlutterLocalNotificationsPlugin();

  static Future<void> init() async {
    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');

    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const settings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _notifications.initialize(settings);
  }

  static Future<void> show({
    required int id,
    required String title,
    required String body,
    bool ongoing = false,
    bool progress = false,
    int maxProgress = 100,
    int currentProgress = 0,
  }) async {
    final android = AndroidNotificationDetails(
      'yowshare_channel',
      'YowShare Transfers',
      channelDescription: 'File transfer status',
      importance: Importance.max,
      priority: Priority.high,
      ongoing: ongoing,
      onlyAlertOnce: true,
      showProgress: progress,
      maxProgress: maxProgress,
      progress: currentProgress,
    );

    final ios = DarwinNotificationDetails(
      presentAlert: true,
      presentSound: false,
    );

    final details = NotificationDetails(android: android, iOS: ios);

    await _notifications.show(id, title, body, details);
  }

  static Future<void> cancel(int id) async {
    await _notifications.cancel(id);
  }

  static Future<void> cancelAll() async {
    await _notifications.cancelAll();
  }
}
