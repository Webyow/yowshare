import 'dart:async';
import 'dart:io';

class ShareIntentHandler {
  static final _controller = StreamController<List<String>>.broadcast();

  static Stream<List<String>> get onSharedFiles => _controller.stream;

  static Future<void> init() async {
    if (!Platform.isAndroid && !Platform.isIOS) {
      return; // no share intent on desktop
    }

    // Import inside condition to avoid Windows errors
    final ReceiveSharingIntent = await _loadMobileIntent();

    ReceiveSharingIntent.getMediaStream().listen((files) {
      _controller.add(files.map((e) => e.path).toList());
    });

    final initial = await ReceiveSharingIntent.getInitialMedia();
    if (initial.isNotEmpty) {
      _controller.add(initial.map((e) => e.path).toList());
    }
  }
}

Future<dynamic> _loadMobileIntent() async {
  return await Future.sync(() => throw UnimplementedError());
}
