import 'dart:async';
import 'dart:convert';
import 'dart:io';

class DeviceInfo {
  final String name;
  final String ip;
  final int port;

  DeviceInfo({
    required this.name,
    required this.ip,
    required this.port,
  });
}

class DeviceDiscovery {
  static const int discoveryPort = 54321;
  static const int serverPort = 8888;

  static RawDatagramSocket? _udpSocket;
  static Timer? _broadcastTimer;

  static final StreamController<DeviceInfo> _deviceStreamController =
      StreamController<DeviceInfo>.broadcast();

  static Stream<DeviceInfo> get onDeviceFound =>
      _deviceStreamController.stream;

  // ------------------------------------------------------------
  // PUBLIC API
  // ------------------------------------------------------------
  static Future<void> startListening(void Function(DeviceInfo) onDeviceFound) async {
    stop();

    if (_isMobile) {
      return _startMobileListening(onDeviceFound);
    } else if (_isDesktop) {
      return _startDesktopListening(onDeviceFound);
    }
  }

  static Future<void> startBroadcasting() async {
    stop();

    if (_isMobile) {
      return _startMobileBroadcasting();
    } else if (_isDesktop) {
      return _startDesktopBroadcasting();
    }
  }

  static void stop() {
    _broadcastTimer?.cancel();
    _broadcastTimer = null;

    _udpSocket?.close();
    _udpSocket = null;
  }

  // ------------------------------------------------------------
  // PLATFORM CHECKS
  // ------------------------------------------------------------
  static bool get _isMobile =>
      Platform.isAndroid || Platform.isIOS;

  static bool get _isDesktop =>
      Platform.isWindows || Platform.isLinux || Platform.isMacOS;

  // ------------------------------------------------------------
  // MOBILE IMPLEMENTATION (Broadcast)
  // ------------------------------------------------------------
  static Future<void> _startMobileBroadcasting() async {
    final ip = await _getLocalIP();
    if (ip == null) return;

    final hostname = Platform.localHostname;

    _udpSocket = await RawDatagramSocket.bind(
      InternetAddress.anyIPv4,
      discoveryPort,
      reuseAddress: true,
    );

    _broadcastTimer = Timer.periodic(
      const Duration(milliseconds: 1500),
      (_) {
        final data = jsonEncode({
          "deviceName": hostname,
          "ip": ip,
          "port": serverPort,
        });

        _udpSocket!.send(
          utf8.encode(data),
          InternetAddress("255.255.255.255"),
          discoveryPort,
        );
      },
    );
  }

  static Future<void> _startMobileListening(
      void Function(DeviceInfo) onDeviceFound) async {
    _udpSocket = await RawDatagramSocket.bind(
      InternetAddress.anyIPv4,
      discoveryPort,
      reuseAddress: true,
    );

    _udpSocket!.broadcastEnabled = true;

    _udpSocket!.listen((event) {
      if (event == RawSocketEvent.read) {
        final packet = _udpSocket!.receive();
        if (packet == null) return;

        final data = utf8.decode(packet.data);
        final json = jsonDecode(data);

        onDeviceFound(
          DeviceInfo(
            name: json["deviceName"],
            ip: json["ip"],
            port: json["port"],
          ),
        );
      }
    });
  }

  // ------------------------------------------------------------
  // DESKTOP IMPLEMENTATION (Multicast)
  // ------------------------------------------------------------
  static const multicastGroup = "239.255.255.250";

  static Future<void> _startDesktopBroadcasting() async {
    final ip = await _getLocalIP();
    if (ip == null) return;

    final hostname = Platform.localHostname;

    _udpSocket = await RawDatagramSocket.bind(
      InternetAddress.anyIPv4,
      0,
      reuseAddress: true,
    );

    final group = InternetAddress(multicastGroup);

    _udpSocket!.joinMulticast(group);

    _broadcastTimer = Timer.periodic(
      const Duration(milliseconds: 2000),
      (_) {
        final data = jsonEncode({
          "deviceName": hostname,
          "ip": ip,
          "port": serverPort,
        });

        _udpSocket!.send(
          utf8.encode(data),
          group,
          discoveryPort,
        );
      },
    );
  }

  static Future<void> _startDesktopListening(
      void Function(DeviceInfo) onDeviceFound) async {
    final group = InternetAddress(multicastGroup);

    _udpSocket = await RawDatagramSocket.bind(
      InternetAddress.anyIPv4,
      discoveryPort,
      reuseAddress: true,
    );

    _udpSocket!.joinMulticast(group);

    _udpSocket!.listen((event) {
      if (event == RawSocketEvent.read) {
        final packet = _udpSocket!.receive();
        if (packet == null) return;

        final data = utf8.decode(packet.data);
        final json = jsonDecode(data);

        onDeviceFound(DeviceInfo(
          name: json["deviceName"],
          ip: json["ip"],
          port: json["port"],
        ));
      }
    });
  }

  // ------------------------------------------------------------
  // GET LOCAL IP
  // ------------------------------------------------------------
  static Future<String?> _getLocalIP() async {
    try {
      final interfaces = await NetworkInterface.list(
        includeLinkLocal: false,
        type: InternetAddressType.IPv4,
      );

      for (var iface in interfaces) {
        for (var addr in iface.addresses) {
          final ip = addr.address;
          if (ip.startsWith("192.") ||
              ip.startsWith("10.") ||
              ip.startsWith("172.")) {
            return ip;
          }
        }
      }
    } catch (_) {}

    return null;
  }
}
