import 'dart:async';
import 'dart:io';
import 'dart:convert';
import 'package:path/path.dart' as p;

class SenderInfo {
  final String ip;
  final String deviceName;
  final int fileCount;
  SenderInfo(this.ip, this.deviceName, this.fileCount);
}

// Event streams
class LocalServer {
  static HttpServer? _server;

  // Incoming request event (file sender wants to send)
  static final StreamController<SenderInfo> _incomingRequestController =
      StreamController.broadcast();

  static Stream<SenderInfo> get onIncomingRequest =>
      _incomingRequestController.stream;

  // Accept or Reject flags stored per sender
  static final Map<String, Completer<bool>> _pendingRequests = {};

  // Progress per file
  static final StreamController<double> _progressController =
      StreamController.broadcast();

  static Stream<double> get onProgress => _progressController.stream;

  static Future<void> start({int port = 8888}) async {
    if (_server != null) return;

    _server = await HttpServer.bind(
      InternetAddress.anyIPv4,
      port,
      shared: true,
    );

    print("Local server running on port $port");

    _server!.listen(
      (HttpRequest req) {
        if (req.uri.path == "/handshake") {
          _handleHandshake(req);
        } else if (req.uri.path == "/upload") {
          _handleUpload(req);
        } else {
          req.response.statusCode = 404;
          req.response.close();
        }
      },
      onError: (e) => print("SERVER ERROR: $e"),
    );
  }

  static Future<void> stop() async {
    await _server?.close();
    _server = null;
  }

  // -----------------------------
  // 1. Sender handshake request
  // -----------------------------
  static void _handleHandshake(HttpRequest req) async {
    try {
      final senderIp = req.connectionInfo!.remoteAddress.address;

      final data = await utf8.decoder.bind(req).join();
      final body = jsonDecode(data);

      final senderName = body["deviceName"];
      final fileCount = body["fileCount"];

      final info = SenderInfo(senderIp, senderName, fileCount);

      // Create completer for accept/reject
      final completer = Completer<bool>();
      _pendingRequests[senderIp] = completer;

      // Notify UI
      _incomingRequestController.add(info);

      // Wait for user decision
      final allowed = await completer.future;

      req.response.write(jsonEncode({"accepted": allowed}));
      await req.response.close();
    } catch (e) {
      print("ERROR in handshake: $e");
      req.response.statusCode = 500;
      req.response.close();
    }
  }

  // -----------------------------
  // Accept / Reject from UI
  // -----------------------------
  static void acceptRequest(SenderInfo info) {
    final completer = _pendingRequests[info.ip];
    if (completer != null && !completer.isCompleted) {
      completer.complete(true);
    }
  }

  static void rejectRequest(SenderInfo info) {
    final completer = _pendingRequests[info.ip];
    if (completer != null && !completer.isCompleted) {
      completer.complete(false);
    }
  }

  // -----------------------------
  // 2. Handle file uploads
  // -----------------------------
  static void _handleUpload(HttpRequest req) async {
    try {
      final contentLength = req.headers.contentLength;
      final fileName = req.headers.value("x-file-name") ?? "file.bin";

      final savePath = await _getSavePath(fileName);

      final file = File(savePath);
      final sink = file.openWrite();

      int bytesReceived = 0;

      await for (var data in req) {
        bytesReceived += data.length;
        sink.add(data);

        final progress = (bytesReceived / contentLength) * 100;
        _progressController.add(progress);
      }

      await sink.close();

      req.response.write(jsonEncode({"status": "success"}));
      await req.response.close();
    } catch (e) {
      print("UPLOAD ERROR: $e");
      req.response.statusCode = 500;
      req.response.close();
    }
  }

  // Save to Downloads/ directory
  static Future<String> _getSavePath(String fileName) async {
    final dir = Directory.systemTemp.path; // cross-platform safe temp
    final path = p.join(dir, "YowShare_$fileName");
    return path;
  }
}
