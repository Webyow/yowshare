import 'dart:io';
import 'package:permission_handler/permission_handler.dart';

class Permissions {
  static Future<bool> requestAll() async {
    if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
      return true; // desktop does not need permissions
    }

    bool ok = true;

    await Permission.notification.request();

    if (Platform.isAndroid) {
      await Permission.storage.request();
      await Permission.photos.request();
      await Permission.videos.request();
      await Permission.audio.request();
      await Permission.location.request();
    }

    if (Platform.isIOS) {
      await Permission.photos.request();
    }

    return ok;
  }
}
