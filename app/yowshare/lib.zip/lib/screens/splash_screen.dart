import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../theme.dart';
import '../backend/permissions.dart';
import '../backend/device_discovery.dart';
import 'dart:io';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  Future<void> startApp() async {
    // Desktop needs no permissions
    await Permissions.requestAll();

    // Device discovery only for Android/iOS
    if (!Platform.isWindows && !Platform.isLinux && !Platform.isMacOS) {
      DeviceDiscovery.startListening((d) {});
    }

    // Show splash for 1.5 sec
    await Future.delayed(const Duration(milliseconds: 1500));

    if (mounted) {
      Navigator.pushReplacementNamed(context, "/home");
    }
  }

  @override
  void initState() {
    super.initState();
    startApp();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: YowTheme.matteBlack,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SvgPicture.asset(
              "assets/logo.svg",
              width: 140,
              color: Colors.white,
            ).animate().fadeIn(duration: 600.ms).scaleXY(begin: 0.8, end: 1.0),
            const SizedBox(height: 25),
            Text(
              "YowShare",
              style: const TextStyle(
                color: Colors.white,
                fontSize: 32,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
              ),
            ).animate().fadeIn(duration: 900.ms)
          ],
        ),
      ),
    );
  }
}
